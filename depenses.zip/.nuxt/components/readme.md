# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<AtomsButtonBudgetGestion>` | `<atoms-button-budget-gestion>` (components/atoms/button-budget-gestion.vue)
- `<AtomsCost>` | `<atoms-cost>` (components/atoms/cost.vue)
- `<MoleculesAddCostForm>` | `<molecules-add-cost-form>` (components/molecules/add-cost-form.vue)
- `<MoleculesBudgetCostsForm>` | `<molecules-budget-costs-form>` (components/molecules/budget-costs-form.vue)
- `<MoleculesBudgetCostsList>` | `<molecules-budget-costs-list>` (components/molecules/budget-costs-list.vue)
- `<MoleculesBudgetInfos>` | `<molecules-budget-infos>` (components/molecules/budget-infos.vue)
- `<MoleculesDetailsEpargneListe>` | `<molecules-details-epargne-liste>` (components/molecules/details-epargne-liste.vue)
- `<MoleculesDetailsEpargne>` | `<molecules-details-epargne>` (components/molecules/details-epargne.vue)
- `<MoleculesFormAjoutBudget>` | `<molecules-form-ajout-budget>` (components/molecules/form-ajout-budget.vue)
- `<MoleculesFormBudgetInfosOld>` | `<molecules-form-budget-infos-old>` (components/molecules/form-budget-infos.old.vue)
- `<MoleculesFormBudgetInfos>` | `<molecules-form-budget-infos>` (components/molecules/form-budget-infos.vue)
- `<MoleculesListeBudgetsGestion>` | `<molecules-liste-budgets-gestion>` (components/molecules/liste-budgets-gestion.vue)
- `<MoleculesListeConfigForm>` | `<molecules-liste-config-form>` (components/molecules/liste-config-form.vue)
- `<MoleculesListeDepenseQuotidienneMax>` | `<molecules-liste-depense-quotidienne-max>` (components/molecules/liste-depense-quotidienne-max.vue)
- `<MoleculesListeEtatBudgets>` | `<molecules-liste-etat-budgets>` (components/molecules/liste-etat-budgets.vue)
- `<MoleculesNav>` | `<molecules-nav>` (components/molecules/nav.vue)
- `<MoleculesSection>` | `<molecules-section>` (components/molecules/section.vue)
- `<OrganismsConfirmDeleteBudgetPopup>` | `<organisms-confirm-delete-budget-popup>` (components/organisms/confirm-delete-budget-popup.vue)
- `<OrganismsPopupModal>` | `<organisms-popup-modal>` (components/organisms/popup-modal.vue)
- `<AtomsIconsAToZ>` | `<atoms-icons-a-to-z>` (components/atoms/icons/a-to-z.vue)
- `<AtomsIconsBigToSmall>` | `<atoms-icons-big-to-small>` (components/atoms/icons/big-to-small.vue)
- `<AtomsIconsChart>` | `<atoms-icons-chart>` (components/atoms/icons/chart.vue)
- `<AtomsIconsFlow>` | `<atoms-icons-flow>` (components/atoms/icons/flow.vue)
- `<AtomsIconsGoogleIcon>` | `<atoms-icons-google-icon>` (components/atoms/icons/google-icon.vue)
- `<AtomsIconsLimit>` | `<atoms-icons-limit>` (components/atoms/icons/limit.vue)
- `<AtomsIconsSmallToBig>` | `<atoms-icons-small-to-big>` (components/atoms/icons/small-to-big.vue)
- `<AtomsIconsZToA>` | `<atoms-icons-z-to-a>` (components/atoms/icons/z-to-a.vue)
- `<AtomsTextBudgetFlux>` | `<atoms-text-budget-flux>` (components/atoms/text/budget-flux.vue)
- `<AtomsTextBudgetLimit>` | `<atoms-text-budget-limit>` (components/atoms/text/budget-limit.vue)
- `<AtomsTextBudgetProgress>` | `<atoms-text-budget-progress>` (components/atoms/text/budget-progress.vue)
- `<AtomsTextBudgetTotalProgress>` | `<atoms-text-budget-total-progress>` (components/atoms/text/budget-total-progress.vue)
- `<AtomsTextBudgetTotal>` | `<atoms-text-budget-total>` (components/atoms/text/budget-total.vue)
- `<AtomsTextH1>` | `<atoms-text-h1>` (components/atoms/text/h1.vue)
- `<AtomsTextH2>` | `<atoms-text-h2>` (components/atoms/text/h2.vue)
