export const AtomsButtonBudgetGestion = () => import('../../components/atoms/button-budget-gestion.vue' /* webpackChunkName: "components/atoms-button-budget-gestion" */).then(c => wrapFunctional(c.default || c))
export const AtomsCost = () => import('../../components/atoms/cost.vue' /* webpackChunkName: "components/atoms-cost" */).then(c => wrapFunctional(c.default || c))
export const MoleculesAddCostForm = () => import('../../components/molecules/add-cost-form.vue' /* webpackChunkName: "components/molecules-add-cost-form" */).then(c => wrapFunctional(c.default || c))
export const MoleculesBudgetCostsForm = () => import('../../components/molecules/budget-costs-form.vue' /* webpackChunkName: "components/molecules-budget-costs-form" */).then(c => wrapFunctional(c.default || c))
export const MoleculesBudgetCostsList = () => import('../../components/molecules/budget-costs-list.vue' /* webpackChunkName: "components/molecules-budget-costs-list" */).then(c => wrapFunctional(c.default || c))
export const MoleculesBudgetInfos = () => import('../../components/molecules/budget-infos.vue' /* webpackChunkName: "components/molecules-budget-infos" */).then(c => wrapFunctional(c.default || c))
export const MoleculesDetailsEpargneListe = () => import('../../components/molecules/details-epargne-liste.vue' /* webpackChunkName: "components/molecules-details-epargne-liste" */).then(c => wrapFunctional(c.default || c))
export const MoleculesDetailsEpargne = () => import('../../components/molecules/details-epargne.vue' /* webpackChunkName: "components/molecules-details-epargne" */).then(c => wrapFunctional(c.default || c))
export const MoleculesFormAjoutBudget = () => import('../../components/molecules/form-ajout-budget.vue' /* webpackChunkName: "components/molecules-form-ajout-budget" */).then(c => wrapFunctional(c.default || c))
export const MoleculesFormBudgetInfosOld = () => import('../../components/molecules/form-budget-infos.old.vue' /* webpackChunkName: "components/molecules-form-budget-infos-old" */).then(c => wrapFunctional(c.default || c))
export const MoleculesFormBudgetInfos = () => import('../../components/molecules/form-budget-infos.vue' /* webpackChunkName: "components/molecules-form-budget-infos" */).then(c => wrapFunctional(c.default || c))
export const MoleculesListeBudgetsGestion = () => import('../../components/molecules/liste-budgets-gestion.vue' /* webpackChunkName: "components/molecules-liste-budgets-gestion" */).then(c => wrapFunctional(c.default || c))
export const MoleculesListeConfigForm = () => import('../../components/molecules/liste-config-form.vue' /* webpackChunkName: "components/molecules-liste-config-form" */).then(c => wrapFunctional(c.default || c))
export const MoleculesListeDepenseQuotidienneMax = () => import('../../components/molecules/liste-depense-quotidienne-max.vue' /* webpackChunkName: "components/molecules-liste-depense-quotidienne-max" */).then(c => wrapFunctional(c.default || c))
export const MoleculesListeEtatBudgets = () => import('../../components/molecules/liste-etat-budgets.vue' /* webpackChunkName: "components/molecules-liste-etat-budgets" */).then(c => wrapFunctional(c.default || c))
export const MoleculesNav = () => import('../../components/molecules/nav.vue' /* webpackChunkName: "components/molecules-nav" */).then(c => wrapFunctional(c.default || c))
export const MoleculesSection = () => import('../../components/molecules/section.vue' /* webpackChunkName: "components/molecules-section" */).then(c => wrapFunctional(c.default || c))
export const OrganismsConfirmDeleteBudgetPopup = () => import('../../components/organisms/confirm-delete-budget-popup.vue' /* webpackChunkName: "components/organisms-confirm-delete-budget-popup" */).then(c => wrapFunctional(c.default || c))
export const OrganismsPopupModal = () => import('../../components/organisms/popup-modal.vue' /* webpackChunkName: "components/organisms-popup-modal" */).then(c => wrapFunctional(c.default || c))
export const AtomsIconsAToZ = () => import('../../components/atoms/icons/a-to-z.vue' /* webpackChunkName: "components/atoms-icons-a-to-z" */).then(c => wrapFunctional(c.default || c))
export const AtomsIconsBigToSmall = () => import('../../components/atoms/icons/big-to-small.vue' /* webpackChunkName: "components/atoms-icons-big-to-small" */).then(c => wrapFunctional(c.default || c))
export const AtomsIconsChart = () => import('../../components/atoms/icons/chart.vue' /* webpackChunkName: "components/atoms-icons-chart" */).then(c => wrapFunctional(c.default || c))
export const AtomsIconsFlow = () => import('../../components/atoms/icons/flow.vue' /* webpackChunkName: "components/atoms-icons-flow" */).then(c => wrapFunctional(c.default || c))
export const AtomsIconsGoogleIcon = () => import('../../components/atoms/icons/google-icon.vue' /* webpackChunkName: "components/atoms-icons-google-icon" */).then(c => wrapFunctional(c.default || c))
export const AtomsIconsLimit = () => import('../../components/atoms/icons/limit.vue' /* webpackChunkName: "components/atoms-icons-limit" */).then(c => wrapFunctional(c.default || c))
export const AtomsIconsSmallToBig = () => import('../../components/atoms/icons/small-to-big.vue' /* webpackChunkName: "components/atoms-icons-small-to-big" */).then(c => wrapFunctional(c.default || c))
export const AtomsIconsZToA = () => import('../../components/atoms/icons/z-to-a.vue' /* webpackChunkName: "components/atoms-icons-z-to-a" */).then(c => wrapFunctional(c.default || c))
export const AtomsTextBudgetFlux = () => import('../../components/atoms/text/budget-flux.vue' /* webpackChunkName: "components/atoms-text-budget-flux" */).then(c => wrapFunctional(c.default || c))
export const AtomsTextBudgetLimit = () => import('../../components/atoms/text/budget-limit.vue' /* webpackChunkName: "components/atoms-text-budget-limit" */).then(c => wrapFunctional(c.default || c))
export const AtomsTextBudgetProgress = () => import('../../components/atoms/text/budget-progress.vue' /* webpackChunkName: "components/atoms-text-budget-progress" */).then(c => wrapFunctional(c.default || c))
export const AtomsTextBudgetTotalProgress = () => import('../../components/atoms/text/budget-total-progress.vue' /* webpackChunkName: "components/atoms-text-budget-total-progress" */).then(c => wrapFunctional(c.default || c))
export const AtomsTextBudgetTotal = () => import('../../components/atoms/text/budget-total.vue' /* webpackChunkName: "components/atoms-text-budget-total" */).then(c => wrapFunctional(c.default || c))
export const AtomsTextH1 = () => import('../../components/atoms/text/h1.vue' /* webpackChunkName: "components/atoms-text-h1" */).then(c => wrapFunctional(c.default || c))
export const AtomsTextH2 = () => import('../../components/atoms/text/h2.vue' /* webpackChunkName: "components/atoms-text-h2" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
