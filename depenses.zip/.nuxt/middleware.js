const middleware = {}

middleware['landing'] = require('../middleware/landing.js')
middleware['landing'] = middleware['landing'].default || middleware['landing']

export default middleware
