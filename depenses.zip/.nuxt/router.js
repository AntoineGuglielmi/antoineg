import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _654420e0 = () => interopDefault(import('../pages/budgets/index.vue' /* webpackChunkName: "pages/budgets/index" */))
const _798d0343 = () => interopDefault(import('../pages/config.vue' /* webpackChunkName: "pages/config" */))
const _268c25d0 = () => interopDefault(import('../pages/costs/index.vue' /* webpackChunkName: "pages/costs/index" */))
const _5b72fdde = () => interopDefault(import('../pages/epargne.vue' /* webpackChunkName: "pages/epargne" */))
const _f9be36c0 = () => interopDefault(import('../pages/home.vue' /* webpackChunkName: "pages/home" */))
const _62fe5f08 = () => interopDefault(import('../pages/simulation.vue' /* webpackChunkName: "pages/simulation" */))
const _5bc122d3 = () => interopDefault(import('../pages/test.vue' /* webpackChunkName: "pages/test" */))
const _a6f6f6ae = () => interopDefault(import('../pages/costs/duplicate/_costId.vue' /* webpackChunkName: "pages/costs/duplicate/_costId" */))
const _100d69a6 = () => interopDefault(import('../pages/budgets/_budgetId.vue' /* webpackChunkName: "pages/budgets/_budgetId" */))
const _870c95a6 = () => interopDefault(import('../pages/costs/_costId.vue' /* webpackChunkName: "pages/costs/_costId" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/budgets",
    component: _654420e0,
    name: "budgets"
  }, {
    path: "/config",
    component: _798d0343,
    name: "config"
  }, {
    path: "/costs",
    component: _268c25d0,
    name: "costs"
  }, {
    path: "/epargne",
    component: _5b72fdde,
    name: "epargne"
  }, {
    path: "/home",
    component: _f9be36c0,
    name: "home"
  }, {
    path: "/simulation",
    component: _62fe5f08,
    name: "simulation"
  }, {
    path: "/test",
    component: _5bc122d3,
    name: "test"
  }, {
    path: "/costs/duplicate/:costId?",
    component: _a6f6f6ae,
    name: "costs-duplicate-costId"
  }, {
    path: "/budgets/:budgetId",
    component: _100d69a6,
    name: "budgets-budgetId"
  }, {
    path: "/costs/:costId",
    component: _870c95a6,
    name: "costs-costId"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
