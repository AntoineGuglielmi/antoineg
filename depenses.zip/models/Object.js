export class Object {

  constructor(object) {
    this.object = object;
  }

  init() {
    // for(const[k,v] of Object.entries(this.object)) {
    //   this[k] = v;
    // }
  }
  
}